
const streets = [
  "Station Road", "Taylor's Avenue", "Seymour Street", "Hill Street", "Davies Street",
  "Bush Street", "Buchanan Street", "Cullen Street", "Kennedy Street", "Miller Avenue",
  "Andrews Street", "Prospect Terrace", "Towers Street", "Norwood Road", "Ohinemuri Place",
  "O'Meara Place", "McDonald Place", "Waimarie Avenue", "Taniwha Street", "Washington Square"
];

let selected = null;

function createGrid() {
  const grid = document.getElementById("grid");
  grid.innerHTML = "";
  const totalCells = 5 * Math.ceil(streets.length / 5);
  for (let i = 0; i < totalCells; i++) {
    const cell = document.createElement("div");
    cell.className = "cell";
    cell.onclick = () => {
      if (selected) {
        cell.textContent = selected.textContent;
        selected.remove();
        selected = null;
      }
    };
    grid.appendChild(cell);
  }
}

function resetGrid() {
  document.getElementById("street-list").innerHTML = "";
  createGrid();
  streets.forEach(street => {
    const div = document.createElement("div");
    div.className = "street";
    div.textContent = street;
    div.onclick = () => selected = div;
    document.getElementById("street-list").appendChild(div);
  });
}

window.onload = resetGrid;
